@extends('app')
@section('content')
    <form action="{{ route('siswa.save') }}" method="post">
        @csrf

        <section class="hero">
            <div class="hero-text"><span class="eyebrow">Master · Siswa · Add</span>
                <h1 class="hero-title">Add <span class="accent">Siswa</span></h1>
                <p class="hero-sub">Form for adding a new student to the system.</p>
            </div>
            <div class="hero-actions">
                <a href="{{ route('siswa') }}" class="btn btn--ghost">Cancel</a>
                <button class="btn btn--primary" type="submit">Save changes</button>
            </div>
        </section>

        <div class="grid">
            <section class="col-12 card">
                <div class="card-head">
                    <div class="card-title-wrap">
                        <span class="eyebrow">Student data</span>
                        <h2 class="card-title">Add New Siswa</h2>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="field">
                        <label class="field-label" for="nis">NIS
                            <span class="req">*</span>
                        </label>
                        <input id="nis" class="input" type="text" name="nis" value="{{ old('nis') }}"
                            placeholder="NIS" autofocus required>
                    </div>
                    <div class="field">
                        <label class="field-label" for="nisn">NISN
                            <span class="req">*</span>
                        </label>
                        <input id="nisn" class="input" type="text" name="nisn" value="{{ old('nisn') }}"
                            placeholder="NISN" required>
                    </div>
                    <div class="field">
                        <label class="field-label" for="nama">Nama
                            <span class="req">*</span>
                        </label>
                        <input id="nama" class="input" type="text" name="nama" value="{{ old('nama') }}"
                            placeholder="Nama Lengkap" required>
                    </div>
                    <div class="field">
                        <label class="field-label" for="id_kelas">Kelas
                            <span class="req">*</span>
                        </label>
                        <select id="id_kelas" class="select" name="id_kelas" required>
                            <option value="">Pilih Kelas</option>
                            @foreach ($daftarKelas as $kelas)
                                <option value="{{ $kelas->id }}" {{ old('id_kelas') == $kelas->id ? 'selected' : '' }}>
                                    {{ $kelas->nama }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="field">
                        <label class="field-label" for="status">Status
                            <span class="req">*</span>
                        </label>
                        <select id="status" class="select" name="status" required>
                            <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>Active</option>
                            <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <span class="badge dot secondary">Please check the data before saving.</span>
                    <span class="spacer"></span>
                </div>
            </section>
        </div>
    </form>
@endsection
