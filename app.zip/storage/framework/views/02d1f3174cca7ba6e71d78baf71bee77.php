<form action="<?php echo e(isset($pendaftaran) ? route('pendaftaran.update', $pendaftaran->id) : route('pendaftaran.save')); ?>"
    method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($pendaftaran)): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow">Master · Pendaftaran · <?php echo e(isset($pendaftaran) ? 'Ubah' : 'Tambah'); ?></span>
            <h1 class="hero-title"><?php echo e(isset($pendaftaran) ? 'Ubah' : 'Tambah'); ?> <span class="accent">Pendaftaran</span>
            </h1>
            <p class="hero-sub">Tentukan siswa, tempat PKL, dan status pendaftarannya.</p>
        </div>
        <div class="hero-actions">
            <a href="<?php echo e(route('pendaftaran')); ?>" class="btn btn--ghost">Batal</a>
            <button type="submit" class="btn btn--primary"><?php echo e(isset($pendaftaran) ? 'Simpan Perubahan' : 'Simpan'); ?></button>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="card-head">
                <div class="card-title-wrap">
                    <span class="eyebrow">Data pendaftaran</span>
                    <h2 class="card-title"><?php echo e(isset($pendaftaran) ? 'Ubah Pendaftaran' : 'Pendaftaran Baru'); ?></h2>
                </div>
            </div>
            <div class="form-grid">
                <div class="field">
                    <label class="field-label" for="id_siswa">Siswa <span class="req">*</span></label>
                    <select id="id_siswa" class="select" name="id_siswa" required>
                        <option value="">Pilih siswa</option>
                        <?php $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($siswa->id); ?>" <?php if((string) old('id_siswa', $pendaftaran->id_siswa ?? '') === (string) $siswa->id): echo 'selected'; endif; ?>>
                                <?php echo e($siswa->nama); ?> (<?php echo e($siswa->nis); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small role="alert"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label class="field-label" for="id_dudi">DUDI <span class="req">*</span></label>
                    <select id="id_dudi" class="select" name="id_dudi" required>
                        <option value="">Pilih DUDI</option>
                        <?php $__currentLoopData = $dudis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->id); ?>" <?php if((string) old('id_dudi', $pendaftaran->id_dudi ?? '') === (string) $row->id): echo 'selected'; endif; ?>>
                                <?php echo e($row->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_dudi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small role="alert"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="field">
                    <label class="field-label" for="status">Status <span class="req">*</span></label>
                    <select id="status" class="select" name="status" required>
                        <?php $__currentLoopData = ['pending' => 'Pending', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if(old('status', $pendaftaran->status ?? 'pending') === $value): echo 'selected'; endif; ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small role="alert"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </section>
    </div>
</form>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/pendaftaran/_form.blade.php ENDPATH**/ ?>