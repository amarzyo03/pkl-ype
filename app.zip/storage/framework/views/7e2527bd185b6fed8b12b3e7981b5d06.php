<?php $__env->startSection('content'); ?>
    <style>
        .registration-page {
            margin: 0 auto;
            width: 100%;
        }

        .registration-page .registration-submit {
            align-self: flex-center;
            justify-content: center;
            margin-top: 22px;
            min-width: 120px;
        }

        @media (max-width: 720px) {
            .registration-page .registration-submit {
                align-self: stretch;
                width: 100%;
            }
        }
    </style>

    <div class="registration-page">
        <section class="hero">
            <div class="hero-text"><span class="eyebrow">Siswa · Pendaftaran · PKL</span>
                <h1 class="hero-title">Pendaftaran Lokasi Tempat <span class="accent"> PKL</span></h1>
                <p class="hero-sub">Silahkan pilih dudi untuk mendaftar di tempat PKL yang tersedia.</p>
            </div>
            
        </section>

        <div class="grid">
            <section class="col-12 card">
                <div class="card-head">
                    <div class="card-title-wrap">
                        <span class="eyebrow">Daftar DUDI Tersedia</span>
                        <h2 class="card-title">PENDAFTARAN LOKASI TEMPAT PKL</h2>
                    </div>
                </div>
                <form action="<?php echo e(route('userSiswa.pendaftaran.attempt')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-grid">
                        <div class="field">
                            <label class="field-label" for="nama">NAMA<span class="req">*</span></label>
                            <input class="input" type="hidden" id="nama" name="nama" value="<?php echo e($siswa->id); ?>">
                            <input class="input" type="text" value="<?php echo e(strtoupper($siswa->nama)); ?>" readonly>
                        </div>
                        <div class="field">
                            <label class="field-label" for="dudi">DAFTAR DUDI <span class="req">*</span></label>
                            <select id="dudi" class="input" name="dudi" required>
                                <option value="">.:: Pilihan DUDI ::.</option>
                                <?php $__currentLoopData = $dudi->groupBy('id_jurusan'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusanDudi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <optgroup label="<?php echo e($jurusanDudi->first()->jurusan?->nama); ?>">
                                        <?php $__currentLoopData = $jurusanDudi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>" <?php if(old('dudi') == $row->id): echo 'selected'; endif; ?>>
                                                <?php echo e($row->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </optgroup>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['dudi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small role="alert"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <button class="btn btn--primary registration-submit" type="submit">DAFTAR</button>
                </form>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userSiswa/pendaftaran/pendaftaran.blade.php ENDPATH**/ ?>