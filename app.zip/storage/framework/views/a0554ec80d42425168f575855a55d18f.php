<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow"><?php echo e(now()->format('l, d F Y')); ?></span>
            <h1 class="hero-title">Selamat datang, <span class="accent"><?php echo e($siswa->nama); ?></span></h1>
            <p class="hero-sub">
                <?php echo e($siswa->kelas?->nama ?? 'Kelas belum tersedia'); ?>

                <?php if($pendaftaran?->status === 'disetujui' && $pendaftaran->dudi): ?>
                    · PKL di <?php echo e($pendaftaran->dudi->nama); ?>

                <?php endif; ?>
            </p>
        </div>
        <div class="hero-actions">
            <a href="<?php echo e(route('userSiswa.pendaftaran.status')); ?>" class="btn btn--ghost">PKL</a>
            <a href="<?php echo e(route('userSiswa.daftarSiswa')); ?>" class="btn btn--ghost">Siswa</a>
            <a href="<?php echo e(route('userSiswa.absensi')); ?>" class="btn btn--ghost">Absensi</a>
            <a href="<?php echo e(route('userSiswa.jurnal')); ?>" class="btn btn--ghost">Jurnal</a>
            <a href="<?php echo e(route('userSiswa.tugas')); ?>" class="btn btn--ghost">Tugas</a>
        </div>
    </section>

    <section class="kpi-grid" aria-label="Ringkasan aktivitas siswa">
        <article class="kpi-card c-success">
            <div class="kpi-top">
                <div class="kpi-identity">
                    <div class="kpi-icon success"><svg viewBox="0 0 24 24">
                            <path d="M20 6 9 17l-5-5" />
                        </svg></div>
                    <div class="kpi-label">Total absensi</div>
                </div><span class="kpi-pill up"><svg viewBox="0 0 24 24">
                        <path d="M5 12h14" />
                    </svg> Catatan</span>
            </div>
            <div class="kpi-value"><?php echo e($totalAbsensi); ?></div>
            <div class="kpi-compare">Jumlah catatan absensi Anda</div>
        </article>
        <article class="kpi-card c-danger">
            <div class="kpi-top">
                <div class="kpi-identity">
                    <div class="kpi-icon danger"><svg viewBox="0 0 24 24">
                            <path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
                        </svg></div>
                    <div class="kpi-label">Total tugas</div>
                </div><span class="kpi-pill down"><svg viewBox="0 0 24 24">
                        <path d="M5 12h14" />
                    </svg> Tersedia</span>
            </div>
            <div class="kpi-value"><?php echo e($totalTugas); ?></div>
            <div class="kpi-compare"><?php echo e($tugasSelesai); ?> tugas telah Anda kumpulkan</div>
        </article>
        <article class="kpi-card c-purple">
            <div class="kpi-top">
                <div class="kpi-identity">
                    <div class="kpi-icon purple"><svg viewBox="0 0 24 24">
                            <rect x="3" y="4" width="18" height="17" rx="2" />
                            <path d="M16 2v4M8 2v4M3 10h18" />
                        </svg></div>
                    <div class="kpi-label">Total jurnal</div>
                </div><span class="kpi-pill flat"><svg viewBox="0 0 24 24">
                        <path d="M5 12h14" />
                    </svg> Kegiatan</span>
            </div>
            <div class="kpi-value"><?php echo e($totalJurnal); ?></div>
            <div class="kpi-compare">Catatan kegiatan yang sudah dibuat</div>
        </article>
        <article class="kpi-card c-primary">
            <div class="kpi-top">
                <div class="kpi-identity">
                    <div class="kpi-icon primary"><svg viewBox="0 0 24 24">
                            <path d="M3 21h18M5 21V7l8-4v18M19 21V11l-6-4" />
                            <path d="M9 9v.01M9 13v.01M9 17v.01M16 13v.01M16 17v.01" />
                        </svg></div>
                    <div class="kpi-label">Status PKL</div>
                </div><span class="kpi-pill info"><svg viewBox="0 0 24 24">
                        <path d="M5 12h14" />
                    </svg> Pendaftaran</span>
            </div>
            <div class="kpi-value" style="font-size: 1.5rem">
                <?php echo e($pendaftaran ? ucfirst($pendaftaran->status) : 'Belum mendaftar'); ?>

            </div>
            <div class="kpi-compare">
                <?php if($pendaftaran?->status === 'disetujui' && $pendaftaran->dudi): ?>
                    <?php echo e($pendaftaran->dudi->nama); ?>

                <?php elseif($pendaftaran?->status === 'pending'): ?>
                    Menunggu persetujuan
                <?php else: ?>
                    <a href="<?php echo e(route('userSiswa.pendaftaran')); ?>">Daftar tempat PKL</a>
                <?php endif; ?>
            </div>
        </article>
    </section>

    <section class="grid">
        <article class="col-6 card">
            <div class="card-head">
                <div class="card-title-wrap">
                    <span class="eyebrow">Aktivitas terbaru</span>
                    <h2 class="card-title">Absensi terakhir</h2>
                </div>
                <a class="btn btn--ghost" href="<?php echo e(route('userSiswa.absensi')); ?>">Lihat semua</a>
            </div>
            <?php if($absensiTerbaru): ?>
                <p><?php echo e($absensiTerbaru->tanggal->format('d/m/Y')); ?> · <?php echo e(ucfirst($absensiTerbaru->status)); ?></p>
                <?php if($absensiTerbaru->keterangan): ?>
                    <p class="text-muted"><?php echo e($absensiTerbaru->keterangan); ?></p>
                <?php endif; ?>
            <?php else: ?>
                <p class="text-muted">Belum ada catatan absensi.</p>
            <?php endif; ?>
        </article>

        <article class="col-6 card">
            <div class="card-head">
                <div class="card-title-wrap">
                    <span class="eyebrow">Catatan kegiatan</span>
                    <h2 class="card-title">Jurnal terakhir</h2>
                </div>
                <a class="btn btn--ghost" href="<?php echo e(route('userSiswa.jurnal')); ?>">Lihat semua</a>
            </div>
            <?php if($jurnalTerbaru): ?>
                <p><?php echo e(\Illuminate\Support\Carbon::parse($jurnalTerbaru->tanggal)->format('d/m/Y')); ?></p>
                <p class="text-muted"><?php echo e($jurnalTerbaru->kegiatan); ?></p>
            <?php else: ?>
                <p class="text-muted">Belum ada catatan jurnal.</p>
            <?php endif; ?>
        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userSiswa/dashboard.blade.php ENDPATH**/ ?>