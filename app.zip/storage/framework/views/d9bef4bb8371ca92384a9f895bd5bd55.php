<?php if($pendaftarans->total() > 0): ?>
    Menampilkan <?php echo e($pendaftarans->firstItem()); ?>–<?php echo e($pendaftarans->lastItem()); ?> dari
    <?php echo e($pendaftarans->total()); ?> pendaftaran
<?php else: ?>
    Tidak ada pendaftaran
<?php endif; ?>

<select class="select per-page-select" data-per-page aria-label="Jumlah pendaftaran per halaman">
    <?php $__currentLoopData = [15, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perPageOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($perPageOption); ?>" <?php echo e($pendaftarans->perPage() == $perPageOption ? 'selected' : ''); ?>>
            <?php echo e($perPageOption); ?> per halaman
        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/pendaftaran/partials/pendaftaran_summary.blade.php ENDPATH**/ ?>