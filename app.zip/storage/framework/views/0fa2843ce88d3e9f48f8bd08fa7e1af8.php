<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>PKL · SMK YPE Kroya</title>
    <script>
        ! function() {
            try {
                var t = localStorage.getItem("dash26-theme"),
                    e = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", t || (e ? "dark" : "light"))
            } catch (t) {
                document.documentElement.setAttribute("data-theme", "light")
            }
        }()
    </script>
    <script defer="defer" src="/assets/runtime.js"></script>
    <script defer="defer" src="/assets/vendor-fullcalendar.js"></script>
    <script defer="defer" src="/assets/vendor-chartjs.js"></script>
    <script defer="defer" src="/assets/vendors.js"></script>
    <script defer="defer" src="/assets/2026.js"></script>
    <script defer="defer" src="/assets/toasts.js"></script>
    <link href="/assets/style.css" rel="stylesheet">
    <link href="/assets/responsive.css" rel="stylesheet">
    <link href="/assets/toasts.css" rel="stylesheet">
</head>

<body
    data-role="<?php echo e(session('auth_role')); ?>"
    data-user-name="<?php echo e(session('auth_name', session('auth_username', ''))); ?>"
    data-user-role="<?php echo e(session('auth_role', '')); ?>"
    data-active="<?php echo e(request()->segment(1) === 'id' ? (request()->segment(3) === 'pendaftaran' ? 'pendaftaran-siswa' : (request()->segment(3) === 'tugas' || request()->segment(3) === 'jurnal' || request()->segment(3) === 'absensi' ? request()->segment(3) . '-' . request()->segment(2) : request()->segment(3))) : (request()->segment(1) ?: 'dashboard')); ?>"
    data-crumbs="">
    <div class="shell">
        <div data-shell-sidebar></div>
        <div class="main">
            <div data-shell-topbar></div>
            <main class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            <div data-shell-footer></div>
        </div>
    </div>
    <?php echo $__env->make('partials.toasts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/app.blade.php ENDPATH**/ ?>