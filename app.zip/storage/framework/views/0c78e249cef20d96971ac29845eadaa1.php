<?php $__empty_1 = true; $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="data-row">
        <td><?php echo e($gurus->firstItem() + $loop->index); ?></td>
        <td>
            <div class="data-cell-user">
                <div class="av ma-2"><?php echo e(strtoupper(substr($row->nama, 0, 1))); ?></div>
                <div class="data-cell-user-meta">
                    <div class="data-cell-user-name"><?php echo e(ucwords($row->nama)); ?></div>
                </div>
            </div>
        </td>
        <td>
            <div class="data-cell-actions">
                <a href="<?php echo e(route('guru.edit', $row->id)); ?>" class="btn--icon" aria-label="Edit" title="Edit">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 20h9" />
                        <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4z" />
                    </svg>
                </a>
                <form action="<?php echo e(route('guru.delete', $row->id)); ?>" method="post" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn--icon btn--icon-delete" aria-label="Delete" title="Delete">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 6h18" />
                            <path d="M8 6V4h8v2" />
                            <path d="M19 6l-1 14H6L5 6" />
                            <path d="M10 11v6M14 11v6" />
                        </svg>
                    </button>
                </form>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="3" class="text-center text-muted">Belum ada data guru.</td>
    </tr>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/guru/partials/guru_rows.blade.php ENDPATH**/ ?>