<?php
    $toastNotifications = [];

    foreach ([
        'success' => 'success',
        'error' => 'error',
        'failed' => 'error',
        'warning' => 'warning',
        'info' => 'info',
        'status' => 'info',
        'message' => 'info',
    ] as $sessionKey => $type) {
        $message = session($sessionKey);

        if (is_string($message) && trim($message) !== '') {
            $toastNotifications[] = ['type' => $type, 'message' => $message];
        } elseif (is_array($message)) {
            foreach ($message as $item) {
                if (is_string($item) && trim($item) !== '') {
                    $toastNotifications[] = ['type' => $type, 'message' => $item];
                }
            }
        }
    }

    foreach (($errors ?? collect())->all() as $message) {
        $toastNotifications[] = ['type' => 'error', 'message' => $message];
    }
?>

<div class="toast-container" data-toast-container aria-live="polite" aria-atomic="false">
    <?php $__currentLoopData = $toastNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
            class="toast"
            data-toast
            data-toast-type="<?php echo e($notification['type']); ?>"
            data-toast-message="<?php echo e($notification['message']); ?>"
            hidden
        ></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/partials/toasts.blade.php ENDPATH**/ ?>