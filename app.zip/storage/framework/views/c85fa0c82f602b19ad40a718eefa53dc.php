<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow">Siswa · Jurnal</span>
            <h1 class="hero-title">Jurnal <span class="accent">Kegiatan</span></h1>
            <p class="hero-sub">Catat dan kelola kegiatan harian Anda.</p>
        </div>
        <div class="hero-actions">
            <a href="<?php echo e(route('userSiswa.jurnal.add')); ?>" class="btn btn--primary">Tambah jurnal</a>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel jurnal siswa">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:32px">#</th>
                            <th>Tanggal</th>
                            <th>Kegiatan</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $jurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(\Illuminate\Support\Carbon::parse($item->tanggal)->format('d/m/Y')); ?></td>
                                <td><?php echo e($item->kegiatan); ?></td>
                                <td>
                                    <div class="data-cell-actions">
                                        <a href="<?php echo e(route('userSiswa.jurnal.edit', $item->id)); ?>"
                                            class="btn--icon" aria-label="Edit" title="Edit">
                                            <svg viewBox="0 0 24 24">
                                                <path d="M12 20h9" />
                                                <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4z" />
                                            </svg>
                                        </a>
                                        <form
                                            action="<?php echo e(route('userSiswa.jurnal.delete', $item->id)); ?>"
                                            method="post" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn--icon btn--icon-delete" aria-label="Hapus"
                                                title="Hapus">
                                                <svg viewBox="0 0 24 24">
                                                    <path d="M3 6h18" />
                                                    <path d="M8 6V4h8v2" />
                                                    <path d="M19 6l-1 14H6L5 6" />
                                                    <path d="M10 11v6M14 11v6" />
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">Belum ada jurnal.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userSiswa/jurnal/index.blade.php ENDPATH**/ ?>