<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text"><span class="eyebrow">Master · Kelas</span>
            <h1 class="hero-title">Data <span class="accent">Kelas</span></h1>
            <p class="hero-sub">Manajemen Data Kelas</p>
        </div>
        <div class="hero-actions">
            
            <a href="<?php echo e(route('kelas.add')); ?>" class="btn btn--primary">
                <svg viewBox="0 0 24 24">
                    <path d="M12 5v14M5 12h14" />
                </svg> Add kelas
            </a>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="data-toolbar">
                <div class="data-toolbar-left">
                    <div class="input-icon" style="flex:1;max-width:420px">
                        <span class="ico">
                            <svg viewBox="0 0 24 24">
                                <circle cx="11" cy="11" r="7" />
                                <path d="m21 21-4.3-4.3" />
                            </svg>
                        </span>
                        <input id="kelas-search" class="input" type="search" name="search"
                            placeholder="Search kelas by name, jurusan, or ID..." value="<?php echo e(request('search', '')); ?>">
                    </div>
                </div>
            </div>

            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel data kelas">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:32px"> # </th>
                            <th>Nama</th>
                            <th>Jurusan</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody id="kelas-table-body">
                        <?php echo $__env->make('kelas.partials.kelas_rows', ['kelas' => $kelas], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </tbody>
                </table>
            </div>

            <div class="data-foot">
                <div class="data-foot-info" id="kelas-summary">
                    <?php echo $__env->make('kelas.partials.kelas_summary', ['kelas' => $kelas], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
                <div class="pager" id="kelas-pager">
                    <?php echo $__env->make('kelas.partials.kelas_pager', ['kelas' => $kelas], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </section>
    </div>

    <script>
        const kelasIndexUrl = "<?php echo e(route('kelas')); ?>";
        const searchInput = document.getElementById('kelas-search');
        const tableBody = document.getElementById('kelas-table-body');
        const summaryContainer = document.getElementById('kelas-summary');
        const pagerContainer = document.getElementById('kelas-pager');

        function buildQueryParams(page = 1) {
            const params = new URLSearchParams();
            const search = searchInput.value.trim();
            const perPage = document.querySelector('[data-per-page]')?.value || '15';

            if (search) {
                params.set('search', search);
            }

            params.set('perPage', perPage);
            params.set('page', page);
            params.set('ajax', '1');

            return params;
        }

        function updateList(page = 1) {
            const params = buildQueryParams(page);
            const url = `${kelasIndexUrl}?${params.toString()}`;

            fetch(url, {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    tableBody.innerHTML = data.rows;
                    summaryContainer.innerHTML = data.summary;
                    pagerContainer.innerHTML = data.pager;

                    const summaryUrl = new URL(kelasIndexUrl, window.location.origin);
                    summaryUrl.search = params.toString().replace(/&ajax=1/g, '');
                    history.replaceState({}, '', summaryUrl.toString().replace(window.location.origin, ''));
                })
                .catch(error => {
                    console.error(error);
                    window.showToast('Gagal memuat data kelas. Silakan coba lagi.', 'error');
                });
        }

        let searchTimer;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => updateList(1), 300);
        });

        document.addEventListener('change', function(event) {
            if (event.target.matches('[data-per-page]')) {
                updateList(1);
            }
        });

        document.addEventListener('click', function(event) {
            const paginationButton = event.target.closest('[data-page]');
            if (!paginationButton) {
                return;
            }

            event.preventDefault();
            updateList(paginationButton.dataset.page);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/kelas/index.blade.php ENDPATH**/ ?>