<div class="table-responsive" tabindex="0" role="region" aria-label="Tabel absensi siswa">
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:32px">#</th>
                <th>Tanggal Absensi</th>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>DUDI</th>
                <th>Foto</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="data-row">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($row->tanggal->format('d/m/Y')); ?></td>
                    <td><?php echo e($row->siswa?->nama ?? 'Siswa tidak tersedia'); ?></td>
                    <td><?php echo e($row->siswa?->kelas?->nama ?? '-'); ?></td>
                    <td><?php echo e($row->siswa?->pendaftaran?->dudi?->nama ?? '-'); ?></td>
                    <td>
                        <?php if($row->foto): ?>
                            <a href="<?php echo e(asset('assets/static/absensi/' . $row->foto)); ?>" target="_blank"
                                rel="noopener">
                                Lihat foto
                            </a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php
                            $statusClass = match ($row->status) {
                                'hadir' => 'success',
                                'sakit', 'izin' => 'warning',
                                'alpa' => 'danger',
                                default => 'info',
                            };
                        ?>
                        <span class="badge dot <?php echo e($statusClass); ?>"><?php echo e(ucfirst($row->status)); ?></span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">
                        <?php if($tanggal): ?>
                            Tidak ada data absensi pada
                            <?php echo e(\Illuminate\Support\Carbon::parse($tanggal)->format('d/m/Y')); ?>.
                        <?php else: ?>
                            Belum ada data absensi.
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="data-foot">
    <div class="data-foot-info">
        <?php if($absensi->isNotEmpty()): ?>
            Menampilkan <?php echo e($absensi->count()); ?> absensi
            <?php if($tanggal): ?>
                pada <?php echo e(\Illuminate\Support\Carbon::parse($tanggal)->format('d/m/Y')); ?>

            <?php else: ?>
                dari semua tanggal
            <?php endif; ?>
        <?php else: ?>
            <?php if($tanggal): ?>
                Tidak ada absensi pada tanggal ini
            <?php else: ?>
                Tidak ada data absensi
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/userGuru/absensi/_results.blade.php ENDPATH**/ ?>