<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('siswa.save')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <section class="hero">
            <div class="hero-text"><span class="eyebrow">Master · Siswa · Add</span>
                <h1 class="hero-title">Add <span class="accent">Siswa</span></h1>
                <p class="hero-sub">Form for adding a new student to the system.</p>
            </div>
            <div class="hero-actions">
                <a href="<?php echo e(route('siswa')); ?>" class="btn btn--ghost">Cancel</a>
                <button class="btn btn--primary" type="submit">Save changes</button>
            </div>
        </section>

        <div class="grid">
            <section class="col-12 card">
                <div class="card-head">
                    <div class="card-title-wrap">
                        <span class="eyebrow">Student data</span>
                        <h2 class="card-title">Add New Siswa</h2>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="field">
                        <label class="field-label" for="nis">NIS
                            <span class="req">*</span>
                        </label>
                        <input id="nis" class="input" type="text" name="nis" value="<?php echo e(old('nis')); ?>"
                            placeholder="NIS" autofocus required>
                    </div>
                    <div class="field">
                        <label class="field-label" for="nisn">NISN
                            <span class="req">*</span>
                        </label>
                        <input id="nisn" class="input" type="text" name="nisn" value="<?php echo e(old('nisn')); ?>"
                            placeholder="NISN" required>
                    </div>
                    <div class="field">
                        <label class="field-label" for="nama">Nama
                            <span class="req">*</span>
                        </label>
                        <input id="nama" class="input" type="text" name="nama" value="<?php echo e(old('nama')); ?>"
                            placeholder="Nama Lengkap" required>
                    </div>
                    <div class="field">
                        <label class="field-label" for="id_kelas">Kelas
                            <span class="req">*</span>
                        </label>
                        <select id="id_kelas" class="select" name="id_kelas" required>
                            <option value="">Pilih Kelas</option>
                            <?php $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kelas->id); ?>" <?php echo e(old('id_kelas') == $kelas->id ? 'selected' : ''); ?>>
                                    <?php echo e($kelas->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="field">
                        <label class="field-label" for="status">Status
                            <span class="req">*</span>
                        </label>
                        <select id="status" class="select" name="status" required>
                            <option value="active" <?php echo e(old('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                            <option value="inactive" <?php echo e(old('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <span class="badge dot secondary">Please check the data before saving.</span>
                    <span class="spacer"></span>
                </div>
            </section>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/siswa/add.blade.php ENDPATH**/ ?>