<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow">Guru · Jurnal</span>
            <h1 class="hero-title">Monitoring <span class="accent">Jurnal Siswa</span></h1>
            <p class="hero-sub">Pantau kegiatan siswa dari DUDI bimbingan Anda.</p>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel jurnal siswa">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:32px">#</th>
                            <th>Tanggal</th>
                            <th>Nama Siswa</th>
                            <th>Kelas</th>
                            <th>DUDI</th>
                            <th>Kegiatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $jurnal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(\Illuminate\Support\Carbon::parse($item->tanggal)->format('d/m/Y')); ?></td>
                                <td><?php echo e($item->siswa?->nama ?? 'Siswa tidak tersedia'); ?></td>
                                <td><?php echo e($item->siswa?->kelas?->nama ?? '-'); ?></td>
                                <td><?php echo e($item->siswa?->pendaftaran?->dudi?->nama ?? '-'); ?></td>
                                <td><?php echo e($item->kegiatan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">Belum ada jurnal siswa bimbingan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="data-foot">
                <div class="data-foot-info">Menampilkan <?php echo e($jurnal->count()); ?> jurnal siswa bimbingan</div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userGuru/jurnal/index.blade.php ENDPATH**/ ?>