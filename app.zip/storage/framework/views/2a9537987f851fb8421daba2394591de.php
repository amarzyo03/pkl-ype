<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow">Siswa · DUDI</span>
            <h1 class="hero-title">Daftar <span class="accent">Siswa</span></h1>
            <p class="hero-sub">Siswa yang terdaftar pada DUDI yang sama dengan Anda.</p>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel siswa satu DUDI">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:32px">#</th>
                            <th>Nama Siswa</th>
                            <th>Kelas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(ucfirst($pendaftaran->siswa?->nama) ?? 'Siswa tidak tersedia'); ?></td>
                                <td><?php echo e(strtoupper($pendaftaran->siswa?->kelas?->nama) ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">
                                    Belum ada siswa yang disetujui pada DUDI yang sama.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="data-foot">
                <div class="data-foot-info">
                    <?php if($daftarSiswa->isNotEmpty()): ?>
                        Menampilkan <?php echo e($daftarSiswa->count()); ?> siswa
                    <?php else: ?>
                        Tidak ada siswa
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userSiswa/daftar-siswa/index.blade.php ENDPATH**/ ?>