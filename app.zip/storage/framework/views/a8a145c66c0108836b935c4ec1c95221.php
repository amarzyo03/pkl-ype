<span>Showing <strong style="color:var(--t-base)"><?php echo e($jurusans->firstItem()); ?>–<?php echo e($jurusans->lastItem()); ?></strong> of
    <strong style="color:var(--t-base)"><?php echo e($jurusans->total()); ?></strong>
</span>
<select class="select per-page-select" data-per-page>
    <?php $__currentLoopData = [15, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perPageOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($perPageOption); ?>" <?php echo e($jurusans->perPage() == $perPageOption ? 'selected' : ''); ?>>
            <?php echo e($perPageOption); ?> per page
        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/jurusan/partials/jurusan_summary.blade.php ENDPATH**/ ?>