<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('guru.update', $guru->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <section class="hero">
            <div class="hero-text"><span class="eyebrow">Master · Guru · Edit</span>
                <h1 class="hero-title">Edit <span class="accent">Guru</span></h1>
                <p class="hero-sub">Perbarui nama guru.</p>
            </div>
            <div class="hero-actions">
                <a href="<?php echo e(route('guru')); ?>" class="btn btn--ghost">Cancel</a>
                <button class="btn btn--primary" type="submit">Update changes</button>
            </div>
        </section>

        <div class="grid">
            <section class="col-12 card">
                <div class="card-head">
                    <div class="card-title-wrap">
                        <span class="eyebrow">Data guru</span>
                        <h2 class="card-title">Edit Guru</h2>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="field">
                        <label class="field-label" for="nama">Nama <span class="req">*</span></label>
                        <input id="nama" class="input" name="nama" value="<?php echo e(old('nama', $guru->nama)); ?>"
                            maxlength="255" required>
                    </div>
                </div>
            </section>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/guru/edit.blade.php ENDPATH**/ ?>