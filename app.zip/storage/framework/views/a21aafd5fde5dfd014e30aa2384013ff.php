<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow"><?php echo e($isAdmin ?? false ? 'Admin · DUDI' : 'Guru · DUDI'); ?></span>
            <h1 class="hero-title">Daftar <span class="accent">DUDI</span></h1>
            <p class="hero-sub">
                <?php echo e($isAdmin ?? false ? 'Daftar DUDI beserta guru pembimbingnya.' : 'Daftar mitra dunia usaha dan dunia industri yang menjadi tanggung jawab Anda.'); ?>

            </p>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel DUDI bimbingan">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:32px">#</th>
                            <th>Nama DUDI</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>PIC</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $dudi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(strtoupper($row->nama)); ?></td>
                                <td><?php echo e($row->alamat); ?></td>
                                <td><?php echo e($row->telp); ?></td>
                                <td><?php echo e(ucwords($row->pic ?? '-')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">
                                    <?php echo e($isAdmin ?? false ? 'Belum ada DUDI dengan guru pembimbing.' : 'Belum ada data DUDI untuk guru ini.'); ?>

                                </td>
                            </tr>   
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="data-foot">
                <div class="data-foot-info">
                    <?php if($dudi->isNotEmpty()): ?>
                        Menampilkan <?php echo e($dudi->count()); ?> DUDI
                    <?php else: ?>
                        Tidak ada DUDI
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userGuru/daftar-dudi/index.blade.php ENDPATH**/ ?>