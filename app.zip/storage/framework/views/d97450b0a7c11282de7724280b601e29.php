<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow">Siswa · Absensi</span>
            <h1 class="hero-title">Daftar <span class="accent">Absensi</span></h1>
            <p class="hero-sub">
                <?php echo e(ucwords($siswa_info->nama) . ' · ' . strtoupper($siswa_info->kelas->nama) . ' · ' . ucwords($dudi->dudi->nama)); ?>

            </p>
        </div>
        <div class="hero-actions">
            <a href="<?php echo e(route('userSiswa.absensi.add')); ?>" class="btn btn--primary">ABSEN</a>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel absensi siswa">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 32px">#</th>
                            <th>Tanggal</th>
                            <th>Foto</th>
                            <th>Keterangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $absensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($row->tanggal->format('d/m/Y')); ?></td>
                                <td>
                                    <?php if($row->foto): ?>
                                        <a href="<?php echo e(asset('assets/static/absensi/' . $row->foto)); ?>" target="_blank"
                                            rel="noopener">
                                            Lihat foto
                                        </a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($row->keterangan); ?></td>
                                <td><?php echo e($row->status); ?></td>
                                <td>
                                    <a class="btn btn--ghost" href="<?php echo e(route('absensi.edit', $row->id)); ?>">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted">Belum ada data absensi</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userSiswa/absensi/index.blade.php ENDPATH**/ ?>