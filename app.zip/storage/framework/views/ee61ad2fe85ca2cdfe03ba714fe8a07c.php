<?php
    $currentPage = $pendaftarans->currentPage();
    $lastPage = $pendaftarans->lastPage();
    $pages = range(1, $lastPage);
?>

<?php if($lastPage > 1): ?>
    <button class="pager-btn" data-page="<?php echo e(max(1, $currentPage - 1)); ?>" aria-label="Sebelumnya"
        <?php echo e($currentPage <= 1 ? 'disabled' : ''); ?>>
        <svg viewBox="0 0 24 24">
            <path d="m15 18-6-6 6-6" />
        </svg>
    </button>

    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button class="pager-btn <?php echo e($page == $currentPage ? 'is-active' : ''); ?>" data-page="<?php echo e($page); ?>"
            <?php echo e($page == $currentPage ? 'disabled' : ''); ?>>
            <?php echo e($page); ?>

        </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <button class="pager-btn" data-page="<?php echo e(min($lastPage, $currentPage + 1)); ?>" aria-label="Selanjutnya"
        <?php echo e($currentPage >= $lastPage ? 'disabled' : ''); ?>>
        <svg viewBox="0 0 24 24">
            <path d="m9 18 6-6-6-6" />
        </svg>
    </button>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/pendaftaran/partials/pendaftaran_pager.blade.php ENDPATH**/ ?>