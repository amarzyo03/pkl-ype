<?php $__empty_1 = true; $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="data-row">
        <td><?php echo e($jurusans->firstItem() + $loop->index); ?></td>
        <td><?php echo e(strtoupper($row->kode)); ?></td>
        <td><?php echo e(ucfirst($row->nama)); ?></td>
        <td>
            <div class="data-cell-actions">
                <a href="<?php echo e(route('jurusan.edit', $row->id)); ?>" class="btn--icon" aria-label="Edit" title="Edit">
                    <svg viewBox="0 0 24 24">
                        <path d="M12 20h9" />
                        <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4z" />
                    </svg>
                </a>
                <form action="<?php echo e(route('jurusan.delete', $row->id)); ?>" method="post" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn--icon btn--icon-delete" aria-label="Delete" title="Delete">
                        <svg viewBox="0 0 24 24">
                            <path d="M3 6h18" />
                            <path d="M8 6V4h8v2" />
                            <path d="M19 6l-1 14H6L5 6" />
                            <path d="M10 11v6M14 11v6" />
                        </svg>
                    </button>
                </form>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="4" class="text-center text-muted">No jurusan data Found.</td>
    </tr>
<?php endif; ?>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/jurusan/partials/jurusan_rows.blade.php ENDPATH**/ ?>