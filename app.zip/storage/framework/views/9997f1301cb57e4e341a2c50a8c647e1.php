<div class="table-responsive" tabindex="0" role="region" aria-label="Tabel daftar tugas">
    <table class="data-table">
        <thead>
            <tr>
                <th style="width:32px">#</th>
                <th>Tanggal</th>
                <th>Judul</th>
                <th>Deskripsi</th>
                <th>Lampiran</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="data-row">
                    <td><?php echo e($tugas->firstItem() + $loop->index); ?></td>
                    <td><?php echo e($row->tanggal->format('d/m/Y')); ?></td>
                    <td><?php echo e($row->judul); ?></td>
                    <td><?php echo e(\Illuminate\Support\Str::limit($row->deskripsi, 120)); ?></td>
                    <td>
                        <?php if($row->file): ?>
                            <a href="<?php echo e(route('tugas.file', $row->id)); ?>"><?php echo e($row->file); ?></a>
                        <?php else: ?>
                            <span class="text-muted">Tidak ada</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('tugas.status', $row->id)); ?>" class="btn btn--ghost btn--small">
                            Lihat status
                        </a>
                    </td>
                    <td>
                        <div class="data-cell-actions">
                            <a href="<?php echo e(route('tugas.edit', $row->id)); ?>" class="btn--icon" aria-label="Ubah tugas"
                                title="Ubah">
                                <svg viewBox="0 0 24 24">
                                    <path d="M12 20h9" />
                                    <path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4z" />
                                </svg>
                            </a>
                            <form action="<?php echo e(route('tugas.delete', $row->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn--icon btn--icon-delete" aria-label="Hapus tugas"
                                    title="Hapus">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M3 6h18" />
                                        <path d="M8 6V4h8v2" />
                                        <path d="M19 6l-1 14H6L5 6" />
                                        <path d="M10 11v6M14 11v6" />
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center text-muted">Belum ada data tugas.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="data-foot">
    <div class="data-foot-info">
        <?php if($tugas->total() > 0): ?>
            Menampilkan <?php echo e($tugas->firstItem()); ?>–<?php echo e($tugas->lastItem()); ?> dari <?php echo e($tugas->total()); ?> tugas
        <?php else: ?>
            Tidak ada tugas
        <?php endif; ?>
        <select class="select" data-per-page aria-label="Jumlah tugas per halaman">
            <?php $__currentLoopData = [15, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perPageOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($perPageOption); ?>" <?php echo e($tugas->perPage() === $perPageOption ? 'selected' : ''); ?>>
                    <?php echo e($perPageOption); ?> per halaman
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="pager">
        <?php if($tugas->onFirstPage()): ?>
            <span class="btn--icon disabled" aria-label="Halaman sebelumnya">‹</span>
        <?php else: ?>
            <a href="<?php echo e($tugas->previousPageUrl()); ?>" class="btn--icon" aria-label="Halaman sebelumnya">‹</a>
        <?php endif; ?>
        <?php $__currentLoopData = $tugas->getUrlRange(max(1, $tugas->currentPage() - 2), min($tugas->lastPage(), $tugas->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($url); ?>" class="btn--icon <?php echo e($page === $tugas->currentPage() ? 'active' : ''); ?>"
                aria-label="Halaman <?php echo e($page); ?>"><?php echo e($page); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($tugas->hasMorePages()): ?>
            <a href="<?php echo e($tugas->nextPageUrl()); ?>" class="btn--icon" aria-label="Halaman berikutnya">›</a>
        <?php else: ?>
            <span class="btn--icon disabled" aria-label="Halaman berikutnya">›</span>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\pkl-ype\resources\views/userGuru/tugas/_results.blade.php ENDPATH**/ ?>