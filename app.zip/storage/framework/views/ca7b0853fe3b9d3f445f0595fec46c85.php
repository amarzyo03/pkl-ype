<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow"><?php echo e(($isAdmin ?? false) ? 'Admin · Siswa' : 'Guru · Siswa'); ?></span>
            <h1 class="hero-title">Daftar <span class="accent">Siswa</span></h1>
            <p class="hero-sub">
                <?php echo e(($isAdmin ?? false) ? 'Siswa yang terdaftar pada DUDI dengan guru pembimbing.' : 'Siswa yang terdaftar pada DUDI bimbingan Anda.'); ?>

            </p>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel siswa bimbingan">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width:32px">#</th>
                            <th>NIS</th>
                            <th>NISN</th>
                            <th>Nama Siswa</th>
                            <th>Kelas</th>
                            <th>DUDI</th>
                            <?php if($isAdmin ?? false): ?>
                                <th>Guru Pembimbing</th>
                            <?php endif; ?>
                            <th>Status Pendaftaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($siswa->nis); ?></td>
                                <td><?php echo e($siswa->nisn); ?></td>
                                <td><?php echo e($siswa->nama); ?></td>
                                <td><?php echo e($siswa->kelas?->nama ?? '-'); ?></td>
                                <td><?php echo e($siswa->pendaftaran?->dudi?->nama ?? '-'); ?></td>
                                <?php if($isAdmin ?? false): ?>
                                    <td><?php echo e($siswa->pendaftaran?->dudi?->guru?->nama ?? '-'); ?></td>
                                <?php endif; ?>
                                <td>
                                    <?php
                                        $statusClass = match ($siswa->pendaftaran?->status) {
                                            'pending' => 'warning',
                                            'disetujui' => 'success',
                                            'ditolak' => 'danger',
                                            default => 'info',
                                        };
                                    ?>
                                    <span class="badge dot <?php echo e($statusClass); ?>">
                                        <?php echo e(ucfirst($siswa->pendaftaran?->status ?? 'Tidak tersedia')); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="<?php echo e(($isAdmin ?? false) ? 8 : 7); ?>" class="text-center text-muted">
                                    <?php echo e(($isAdmin ?? false) ? 'Belum ada siswa yang terdaftar pada DUDI dengan guru pembimbing.' : 'Belum ada siswa yang terdaftar pada DUDI bimbingan Anda.'); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="data-foot">
                <div class="data-foot-info">
                    <?php if($siswas->isNotEmpty()): ?>
                        Menampilkan <?php echo e($siswas->count()); ?> siswa
                    <?php else: ?>
                        Tidak ada siswa
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userGuru/daftar-siswa/index.blade.php ENDPATH**/ ?>