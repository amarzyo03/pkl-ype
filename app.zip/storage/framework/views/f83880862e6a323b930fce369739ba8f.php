<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('pendaftaran._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/pendaftaran/add.blade.php ENDPATH**/ ?>