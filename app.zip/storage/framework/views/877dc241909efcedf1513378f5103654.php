<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('guru.save')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <section class="hero">
            <div class="hero-text"><span class="eyebrow">Master · Guru · Add</span>
                <h1 class="hero-title">Tambah <span class="accent">Guru</span></h1>
                <p class="hero-sub">Tambahkan nama guru.</p>
            </div>
            <div class="hero-actions">
                <a href="<?php echo e(route('guru')); ?>" class="btn btn--ghost">Cancel</a>
                <button class="btn btn--primary" type="submit">Save changes</button>
            </div>
        </section>

        <div class="grid">
            <section class="col-12 card">
                <div class="card-head">
                    <div class="card-title-wrap">
                        <span class="eyebrow">Data guru</span>
                        <h2 class="card-title">Tambah Guru</h2>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="field">
                        <label class="field-label" for="nama">Nama <span class="req">*</span></label>
                        <input id="nama" class="input" name="nama" value="<?php echo e(old('nama')); ?>" maxlength="255"
                            required>
                    </div>
                </div>
            </section>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/guru/add.blade.php ENDPATH**/ ?>