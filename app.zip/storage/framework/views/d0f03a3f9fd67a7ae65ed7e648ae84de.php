<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="hero-text">
            <span class="eyebrow">Siswa · Tugas</span>
            <h1 class="hero-title">Daftar <span class="accent">Tugas</span></h1>
            <p class="hero-sub">Lihat tugas yang diberikan oleh guru.</p>
        </div>
    </section>

    <div class="grid">
        <section class="col-12 card">
            <div class="table-responsive" tabindex="0" role="region" aria-label="Tabel daftar tugas">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 32px">#</th>
                            <th>Tanggal</th>
                            <th>Guru</th>
                            <th>Judul</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="data-row">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($row->tanggal->format('d/m/Y')); ?></td>
                                <td><?php echo e($row->guru?->nama ?? 'Guru tidak tersedia'); ?></td>
                                <td><?php echo e($row->judul); ?></td>
                                <td>
                                    <a href="<?php echo e(route('userSiswa.tugas.kerjakan.attempt', $row->id)); ?>"
                                        class="btn btn--primary">Kerjakan
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">Belum ada data tugas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\pkl-ype\resources\views/userSiswa/tugas/index.blade.php ENDPATH**/ ?>