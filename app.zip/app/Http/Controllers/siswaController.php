<?php

namespace App\Http\Controllers;

use App\Imports\SiswaImport;
use App\Models\kelasModel;
use App\Models\siswaModel;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Maatwebsite\Excel\Facades\Excel;

class siswaController extends Controller
{
    public function index(Request $request)
    {
        $query = siswaModel::query()->with('kelas');

        $search = trim((string) $request->input('search', ''));
        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('nis', 'like', "%{$search}%")
                    ->orWhere('nisn', 'like', "%{$search}%")
                    ->orWhere('nama', 'like', "%{$search}%")
                    ->orWhere('id_kelas', 'like', "%{$search}%")
                    ->orWhereHas('kelas', function ($kelasQuery) use ($search) {
                        $kelasQuery->where('nama', 'like', "%{$search}%");
                    })
                    ->orWhere('id', 'like', "%{$search}%");
            });
        }

        $status = strtolower((string) $request->input('status', 'all'));
        if (in_array($status, ['active', 'inactive'], true)) {
            $query->where('status', $status);
        }

        $perPage = (int) $request->input('perPage', 15);
        if (! in_array($perPage, [15, 25, 50, 100], true)) {
            $perPage = 15;
        }

        $siswas = $query
            ->orderBy('id', 'asc')
            ->paginate($perPage)
            ->appends($request->query());

        if ($request->boolean('ajax')) {
            return response()->json([
                'rows' => view('siswa.partials.siswa_rows', compact('siswas'))->render(),
                'summary' => view('siswa.partials.siswa_summary', compact('siswas'))->render(),
                'pager' => view('siswa.partials.siswa_pager', compact('siswas'))->render(),
            ]);
        }

        return view('siswa.index', compact('siswas'));
    }

    public function add()
    {
        $daftarKelas = kelasModel::orderBy('nama')->get();

        return view('siswa.add', compact('daftarKelas'));
    }

    public function save(Request $request)
    {
        $validated = $request->validate([
            'nis' => ['required', 'string', 'max:255', 'unique:tb_siswa,nis'],
            'nisn' => ['required', 'string', 'max:255', 'unique:tb_siswa,nisn'],
            'nama' => ['required', 'string', 'max:255'],
            'id_kelas' => ['required', 'integer', Rule::exists('tb_kelas', 'id')->whereNull('deleted_at')],
            'status' => ['required', 'in:active,inactive'],
        ]);

        siswaModel::create($validated);

        return redirect()->route('siswa')->with('success', 'Siswa berhasil ditambahkan.');
    }

    public function edit(string $id)
    {
        $siswa = siswaModel::findOrFail($id);
        $daftarKelas = kelasModel::orderBy('nama')->get();

        return view('siswa.edit', compact('siswa', 'daftarKelas'));
    }

    public function update(Request $request, string $id)
    {
        $siswa = siswaModel::findOrFail($id);

        $validated = $request->validate([
            'nis' => ['required', 'string', 'max:255', Rule::unique('tb_siswa', 'nis')->ignore($siswa->id)],
            'nisn' => ['required', 'string', 'max:255', Rule::unique('tb_siswa', 'nisn')->ignore($siswa->id)],
            'nama' => ['required', 'string', 'max:255'],
            'id_kelas' => ['required', 'integer', Rule::exists('tb_kelas', 'id')->whereNull('deleted_at')],
            'status' => ['required', 'in:active,inactive'],
        ]);

        $siswa->update($validated);

        return redirect()->route('siswa')->with('success', 'Siswa berhasil diperbarui.');
    }

    public function delete(string $id)
    {
        $siswa = siswaModel::findOrFail($id);
        $siswa->delete();

        return redirect()->route('siswa')->with('success', 'Siswa berhasil dihapus.');
    }

    public function import()
    {
        return view('siswa.import');
    }

    public function importStore(Request $request)
    {
        $validated = $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx,xls,csv'],
        ]);

        Excel::import(new SiswaImport, $validated['file']);

        return redirect()->route('siswa')->with('success', 'Data siswa berhasil diimport.');
    }
}
